package com.xdl.controller;

import com.xdl.Customer;
import com.xdl.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * @author XuYuDong
 * @version 1.0
 * @description com.xdl.controller
 * @date 2020/3/16
 */
@Controller
@RequestMapping("/customer")
public class CustomerController {
    @Autowired
    private CustomerService customerService;

    public CustomerController(){
        System.out.println("1111");
    }
    /**
     * 跳转到input.jsp
     */
    @RequestMapping("/input")
    public String input(){
        System.out.println("哈哈哈");
        return "input";
    }

    /**
     * 保存
     */
    @RequestMapping("/save")
    public String save(Customer customer){
        customerService.addCoustomer(customer);
        return "succ";
    }
}
