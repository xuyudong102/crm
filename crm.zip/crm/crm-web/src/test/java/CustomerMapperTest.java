import com.xdl.Customer;
import com.xdl.mapper.CustomerMapper;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


/**
 * @author XuYuDong
 * @version 1.0
 * @description PACKAGE_NAME
 * @date 2020/3/16
 */
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("classpath:applicationContext.xml")
public class CustomerMapperTest {
    @Autowired
    private CustomerMapper customerMapper;
    @Test
    public void testSave(){
        Customer customer = new Customer();
        customer.setName("bbc");
        customer.setGender("男");
        customer.setAge(20);
        customerMapper.addCustomer(customer);
    }

}
