package com.xdl.service;

import com.xdl.Customer;

/**
 * @author XuYuDong
 * @version 1.0
 * @description com.xdl.service
 * @date 2020/3/16
 */

public interface CustomerService {
    public void addCoustomer(Customer customer);
}
