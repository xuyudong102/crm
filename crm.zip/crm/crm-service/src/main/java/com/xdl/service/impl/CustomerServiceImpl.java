package com.xdl.service.impl;

import com.xdl.Customer;
import com.xdl.mapper.CustomerMapper;
import com.xdl.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 * @author XuYuDong
 * @version 1.0
 * @description com.xdl.service.impl
 * @date 2020/3/16
 */
@Service("customerService")
@Transactional
public class CustomerServiceImpl implements CustomerService {
    @Autowired
    private CustomerMapper customerMapper;

    @Override
    public void addCoustomer(Customer customer) {
        customerMapper.addCustomer(customer);
    }
}
