package com.xdl.mapper;

import com.xdl.Customer;
import org.springframework.stereotype.Repository;

/**
 * @author XuYuDong
 * @version 1.0
 * @description com.xdl.mapper
 * @date 2020/3/15
 */
@Repository("customerMapper")
public interface CustomerMapper{
    public void addCustomer(Customer customer);

}
